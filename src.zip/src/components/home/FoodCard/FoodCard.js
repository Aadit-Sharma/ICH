import React, { useRef } from "react";
import {
  Animated,
  Image,
  Pressable,
  Text,
  View,
} from "react-native";

import Icon from "react-native-vector-icons/Ionicons";

import styles from "./FoodCardStyles";

export default function FoodCard({
  item,
  onAdd = () => {},
  onPress = () => {},
}) {
  const scale = useRef(new Animated.Value(1)).current;
  const addScale = useRef(new Animated.Value(1)).current;

  const animateScale = (toValue) => {
    Animated.spring(scale, {
      toValue,
      friction: 6,
      tension: 140,
      useNativeDriver: true,
    }).start();
  };

  const animateAddScale = (toValue) => {
    Animated.spring(addScale, {
      toValue,
      friction: 6,
      tension: 170,
      useNativeDriver: true,
    }).start();
  };

  const handleAddPress = (event) => {
    event.stopPropagation();
    onAdd(item);
  };

  return (
    <Animated.View
      style={[
        styles.animatedContainer,
        {
          transform: [{ scale }],
        },
      ]}
    >
      <Pressable
        style={styles.card}
        onPress={() => onPress(item)}
        onPressIn={() => animateScale(0.97)}
        onPressOut={() => animateScale(1)}
      >
        <Image
          source={
            typeof item.image === "string"
              ? { uri: item.image }
              : item.image
          }
          style={styles.image}
          resizeMode="cover"
        />

        <View style={styles.content}>
          <Text
            style={styles.name}
            numberOfLines={1}
          >
            {item.name}
          </Text>

          <View style={styles.metaRow}>
            <Text style={styles.price}>
              ₹ {item.price}
            </Text>

            <View style={styles.rating}>
              <Icon
                name="star"
                size={13}
                color="#F9A826"
              />

              <Text style={styles.ratingText}>
                {item.rating}
              </Text>
            </View>
          </View>

          <Animated.View
            style={{
              transform: [{ scale: addScale }],
            }}
          >
            <Pressable
              style={styles.addButton}
              onPress={handleAddPress}
              onPressIn={() => animateAddScale(0.96)}
              onPressOut={() => animateAddScale(1)}
            >
              <Text style={styles.addButtonText}>
                ADD
              </Text>
            </Pressable>
          </Animated.View>
        </View>
      </Pressable>
    </Animated.View>
  );
}
